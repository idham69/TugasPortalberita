package com.idham.uas_16090016.crud;

public class Konfigurasi {

    public static final String URL_ADD = "http://192.168.43.4/android/mahasiswa/tambahMhs.php";
    public static final String URL_GET_ALL = "http://192.168.43.4/android/mahasiswa/tampilSemuaMhs.php";
    public static final String URL_GET_EMP = "http://192.168.43.4/android/mahasiswa/tampilMhs.php";
    public static final String URL_UPDATE_EMP = "http://192.168.43.4/android/mahasiswa/updateMhs.php";
    public static final String URL_DELETE_EMP = "http://192.168.43.4/android/mahasiswa/hapusMhs.php?id=4";
    //

    public static final String KEY_EMP_ID = "id";
    public static final String KEY_EMP_NAMA = "name";
    public static final String KEY_EMP_NIM = "nim";
    public static final String KEY_EMP_ALAMAT = "alamat";

    //
    public static final String KEY_ID = "id";
    public static final String KEY_SUKA = "suka";

    public static final String TAG_Id = "id";
    public static final String TAG_SUKA = "suka";

    public static final String TAG_JSON_ARRAY = "result";
    public static final String TAG_ID = "id";
    public static final String TAG_NAMA = "name";
    public static final String TAG_NIM = "nim";
    public static final String TAG_ALAMAT = "alamat";

    public static final String EMP_ID = "emp_id";
    public static final String EMP_NAMA = "emp_nama";

    //hp 192.168.43.139
    //plugin 192.168.1.13
}
